#!/bin/sh
ping -c 40 127.0.0.1 > /dev/null
sh /koolshare/scripts/config-frps.sh