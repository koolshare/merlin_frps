#!/bin/sh
sleep 40
sh /koolshare/scripts/config-frps.sh